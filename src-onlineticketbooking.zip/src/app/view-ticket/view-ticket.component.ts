import { Component } from '@angular/core';

@Component({
  selector: 'app-view-ticket',
  standalone: true,
  imports: [],
  templateUrl: './view-ticket.component.html',
  styleUrl: './view-ticket.component.css'
})
export class ViewTicketComponent {

}
